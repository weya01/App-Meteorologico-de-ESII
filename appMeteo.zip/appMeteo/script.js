// Configuração da API
const API_KEY = '2badf455478c84412b3c7875bfa1893d'; // Substitua pela sua chave
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

// Elementos do DOM
const cityInput = document.getElementById('city-input');
const searchBtn = document.getElementById('search-btn');
const locationBtn = document.getElementById('location-btn');
const cityName = document.getElementById('city-name');
const temperature = document.getElementById('temperature');
const weatherIcon = document.getElementById('weather-icon');
const weatherDescription = document.getElementById('weather-description');
const humidity = document.getElementById('humidity');
const windSpeed = document.getElementById('wind-speed');
const forecastContainer = document.getElementById('forecast');
const clothingAdvice = document.getElementById('clothing-advice');

// Função para buscar dados meteorológicos
async function fetchWeatherData(city) {
    try {
        // Busca dados atuais
        const currentResponse = await fetch(`${BASE_URL}/weather?q=${city}&units=metric&appid=${API_KEY}&lang=pt`);
        const currentData = await currentResponse.json();
        
        if (currentData.cod !== 200) {
            throw new Error(currentData.message);
        }
        
        // Busca previsão para 5 dias
        const forecastResponse = await fetch(`${BASE_URL}/forecast?q=${city}&units=metric&appid=${API_KEY}&lang=pt`);
        const forecastData = await forecastResponse.json();
        
        return {
            current: currentData,
            forecast: forecastData
        };
    } catch (error) {
        console.error('Erro ao buscar dados:', error);
        alert(`Erro: ${error.message}`);
        return null;
    }
}

// Função para buscar pelo navegador
async function fetchWeatherByLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
            const { latitude, longitude } = position.coords;
            
            try {
                // Busca dados atuais por coordenadas
                const currentResponse = await fetch(`${BASE_URL}/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=${API_KEY}&lang=pt`);
                const currentData = await currentResponse.json();
                
                // Busca previsão por coordenadas
                const forecastResponse = await fetch(`${BASE_URL}/forecast?lat=${latitude}&lon=${longitude}&units=metric&appid=${API_KEY}&lang=pt`);
                const forecastData = await forecastResponse.json();
                
                updateWeatherUI({
                    current: currentData,
                    forecast: forecastData
                });
            } catch (error) {
                console.error('Erro ao buscar por localização:', error);
                alert('Erro ao obter sua localização');
            }
        }, (error) => {
            console.error('Erro de geolocalização:', error);
            alert('Permissão de localização negada');
        });
    } else {
        alert('Geolocalização não suportada pelo seu navegador');
    }
}

// Função para atualizar a UI com os dados meteorológicos
function updateWeatherUI(data) {
    const { current, forecast } = data;
    
    // Atualiza dados atuais
    cityName.textContent = `${current.name}, ${current.sys.country}`;
    temperature.textContent = `${Math.round(current.main.temp)}°C`;
    weatherIcon.src = `assets/icons/${current.weather[0].icon}.png`;
    weatherDescription.textContent = current.weather[0].description;
    humidity.textContent = `${current.main.humidity}%`;
    windSpeed.textContent = `${Math.round(current.wind.speed * 3.6)} km/h`;
    
    // Atualiza previsão para 5 dias
    forecastContainer.innerHTML = '';
    
    // Filtra para pegar um registro por dia (às 12:00)
    const dailyForecasts = forecast.list.filter(item => {
        return item.dt_txt.includes('12:00:00');
    }).slice(0, 5);
    
    dailyForecasts.forEach(day => {
        const date = new Date(day.dt * 1000);
        const dayName = date.toLocaleDateString('pt-PT', { weekday: 'short' });
        
        const forecastDay = document.createElement('div');
        forecastDay.className = 'forecast-day';
        forecastDay.innerHTML = `
            <h4>${dayName}</h4>
            <img src="assets/icons/${day.weather[0].icon}.png" alt="${day.weather[0].description}">
            <p>${Math.round(day.main.temp_max)}° / ${Math.round(day.main.temp_min)}°</p>
        `;
        
        forecastContainer.appendChild(forecastDay);
    });
    
    // Atualiza recomendações de vestuário (funcionalidade inovadora)
    updateClothingAdvice(current);
}

// Funcionalidade Inovadora: Recomendações de Vestuário
function updateClothingAdvice(weatherData) {
    const temp = weatherData.main.temp;
    const weather = weatherData.weather[0].main.toLowerCase();
    const wind = weatherData.wind.speed;
    
    let advice = '';
    
    if (temp > 30) {
        advice = 'Use roupas leves e claras, chapéu e protetor solar. Mantenha-se hidratado!';
    } else if (temp > 20) {
        advice = 'Roupas leves são ideais. Talvez um casaco fino para a noite.';
    } else if (temp > 10) {
        advice = 'Use um casaco ou suéter. Pode ficar frio à noite.';
    } else if (temp > 0) {
        advice = 'Roupas quentes são essenciais - casaco, luvas e gorro.';
    } else {
        advice = 'Extremamente frio! Use várias camadas, casaco pesado, luvas, gorro e cachecol.';
    }
    
    // Ajustes baseados na condição climática
    if (weather.includes('rain')) {
        advice += ' Leve um guarda-chuva ou impermeável.';
    } else if (weather.includes('snow')) {
        advice += ' Use botas impermeáveis e roupas térmicas.';
    }
    
    // Ajuste para vento
    if (wind > 8) {
        advice += ' Vento forte - considere uma jaqueta corta-vento.';
    }
    
    clothingAdvice.textContent = advice;
}

// Event Listeners
searchBtn.addEventListener('click', async () => {
    const city = cityInput.value.trim();
    if (city) {
        const weatherData = await fetchWeatherData(city);
        if (weatherData) {
            updateWeatherUI(weatherData);
        }
    } else {
        alert('Por favor, digite o nome de uma cidade');
    }
});

locationBtn.addEventListener('click', fetchWeatherByLocation);

// Carrega dados de uma cidade padrão ao iniciar
window.addEventListener('load', () => {
    fetchWeatherData('Luanda').then(data => {
        if (data) updateWeatherUI(data);
    });
});